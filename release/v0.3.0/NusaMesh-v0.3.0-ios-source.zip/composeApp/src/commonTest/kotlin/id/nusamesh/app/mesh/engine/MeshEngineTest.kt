package id.nusamesh.app.mesh.engine

import id.nusamesh.app.mesh.protocol.FilePacket
import id.nusamesh.app.mesh.protocol.MeshMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlin.random.Random
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

@OptIn(ExperimentalCoroutinesApi::class)
class MeshEngineTest {
    private val base = 1_700_000_000_000L

    private class Phone(
        val engine: MeshEngine, val link: FakeLink, val inbox: MutableList<String>, val log: MutableList<String>,
        val files: MutableList<FilePacket>,
    )

    private fun TestScope.world(): FakeRadio {
        val radio = FakeRadio()
        backgroundScope.launch { while (isActive) { radio.scanTick(); delay(1_000) } }
        return radio
    }

    private fun TestScope.phone(radio: FakeRadio, address: String, peerId: String, nick: String): Phone {
        val link = FakeLink(radio, address)
        val log = mutableListOf<String>()
        val engine = MeshEngine(link, peerId, backgroundScope, { base + testScheduler.currentTime }, Random(peerId.hashCode()),
            MobilityLogSink { ev, from, to, _, _, _, detail -> log += "$ev $from->$to $detail" })
        engine.nickname = nick
        val inbox = mutableListOf<String>()
        backgroundScope.launch { engine.messages.collect { inbox += "${it.message.sender}:${it.message.content}" } }
        val files = mutableListOf<FilePacket>()
        backgroundScope.launch { engine.files.collect { files += it.file } }
        engine.start()
        return Phone(engine, link, inbox, log, files)
    }

    private fun TestScope.node(radio: FakeRadio, address: String, n: Int) =
        FakeNode(radio, address, n) { base + testScheduler.currentTime }

    private fun msg(from: String, text: String) = MeshMessage(sender = from, content = text, timestampMs = base)

    @Test
    fun voiceTransferProgressFinishesOnlyAfterAllTransportFragments() = runTest {
        val radio=world()
        val a=phone(radio,"A","0a0a0a0a0a0a0a0a","Ayu")
        val b=phone(radio,"B","0b0b0b0b0b0b0b0b","Budi")
        radio.setRssi("A","B",-55)
        advanceTimeBy(5_000);runCurrent()
        val progress=mutableListOf<Float>()
        val completed=mutableListOf<Boolean>()
        val estimates=mutableListOf<TransferEstimate>()
        val file=FilePacket("voice.c2","audio/x-codec2",Random(2).nextBytes(1200))
        a.engine.sendFile(file,{progress+=it},{completed+=it},onEstimate={estimates+=it})
        advanceTimeBy(10_000);runCurrent()
        assertEquals(listOf(true),completed)
        assertEquals(1f,progress.last())
        assertTrue(progress.zipWithNext().all { (a,b)->b>=a })
        assertTrue(progress.all { it in 0f..1f })
        assertTrue(estimates.any { !it.nodePacing && it.remainingMs!=null && it.completedFragments in 1 until it.totalFragments })
        assertTrue(b.files.any { it.content.contentEquals(file.content) })
    }

    @Test
    fun voiceTransferWithoutPathStopsWaitingWithFailure() = runTest {
        val a=phone(world(),"A","0a0a0a0a0a0a0a0a","Ayu")
        val completed=mutableListOf<Boolean>()
        val progress=mutableListOf<Float>()
        a.engine.sendFile(FilePacket("voice.c2","audio/x-codec2",ByteArray(1200)),{progress+=it},{completed+=it})
        runCurrent()
        assertEquals(listOf(false),completed)
        assertTrue(progress.isEmpty())
    }

    @Test
    fun disconnectStopsPendingVoiceWithFailureInsteadOfStuckLoading() = runTest {
        val radio=world()
        node(radio,"N1",1)
        val a=phone(radio,"A","0a0a0a0a0a0a0a0a","Ayu")
        radio.setRssi("A","N1",-55)
        advanceTimeBy(5_000);runCurrent()
        val completed=mutableListOf<Boolean>()
        val estimates=mutableListOf<TransferEstimate>()
        a.engine.sendFile(FilePacket("voice.c2","audio/x-codec2",Random(5).nextBytes(20_000)),onComplete={completed+=it},onEstimate={estimates+=it})
        runCurrent()
        assertTrue(completed.isEmpty(),completed.toString())
        assertTrue(estimates.any { it.nodePacing && (it.remainingMs ?: 0)>0 && it.completedFragments<it.totalFragments })
        radio.setRssi("A","N1",null)
        runCurrent()
        assertEquals(listOf(false),completed)
    }

    @Test
    fun disconnectFailsQueuedBatchesWithoutClaimingRadioDelivery() = runTest {
        val radio = world()
        node(radio, "N1", 1)
        val a = phone(radio, "A", "0a0a0a0a0a0a0a0a", "Ayu")
        radio.setRssi("A", "N1", -55)
        advanceTimeBy(5_000); runCurrent()
        repeat(5) { a.engine.sendPublic(msg("Ayu", "queued $it")) }
        runCurrent()
        assertTrue(a.engine.diagnostics.snapshot.value.count("QUEUE_ACCEPTED") > 0)
        radio.setRssi("A", "N1", null)
        runCurrent()
        val s = a.engine.diagnostics.snapshot.value
        assertTrue(s.count("BATCH_FAILED") > 0)
        assertEquals(0L, s.acknowledgedMessages)
    }

    @Test
    fun transmissionDiagnosticsCorrelateActualSendAndReceiverAckWithoutLoggingPayload() = runTest {
        val radio = world()
        val a = phone(radio, "A", "0a0a0a0a0a0a0a0a", "Ayu")
        val b = phone(radio, "B", "0b0b0b0b0b0b0b0b", "Budi")
        radio.setRssi("A", "B", -60)
        advanceTimeBy(5_000); runCurrent()
        val message = msg("Ayu", "private payload never belongs in diagnostic logs")
        a.engine.sendPublic(message)
        advanceTimeBy(1_000); runCurrent()
        b.engine.sendAck(a.engine.myPeerId, message.id)
        advanceTimeBy(1_000); runCurrent()
        val s = a.engine.diagnostics.snapshot.value
        assertEquals(1L, s.acknowledgedMessages)
        assertTrue(s.txBytes > 0)
        assertTrue(s.rxBytes > 0)
        assertTrue(s.events.any { it.name == "TX_ACCEPTED" && it.messageId == message.id })
        assertTrue(s.events.any { it.name == "ACK_MATCHED" && it.messageId == message.id })
        assertTrue(s.events.none { it.detail.contains(message.content) })
    }

    @Test
    fun noConnectedPathCannotBeCountedAsBleSuccessOrReceiverDelivery() = runTest {
        val a = phone(world(), "A", "0a0a0a0a0a0a0a0a", "Ayu")
        runCurrent()
        a.engine.sendPublic(msg("Ayu", "no route"))
        runCurrent()
        val s = a.engine.diagnostics.snapshot.value
        assertEquals(1L, s.count("NO_PATH"))
        assertEquals(1L, s.count("MESSAGE_LOCAL_FAILED"))
        assertEquals(0L, s.count("TX_ACCEPTED"))
        assertEquals(0L, s.acknowledgedMessages)
    }

    @Test
    fun messageRelaysThroughMiddlePhone() = runTest {
        val radio = world()
        val a = phone(radio, "A", "0a0a0a0a0a0a0a0a", "Ayu")
        val b = phone(radio, "B", "0b0b0b0b0b0b0b0b", "Budi")
        val c = phone(radio, "C", "0c0c0c0c0c0c0c0c", "Citra")
        radio.setRssi("A", "B", -60); radio.setRssi("B", "C", -60)   // A tidak menjangkau C
        advanceTimeBy(5_000); runCurrent()
        assertTrue(radio.isConnected("A", "B") && radio.isConnected("B", "C"))

        a.engine.sendPublic(msg("Ayu", "jalan utama tertutup"))
        advanceTimeBy(2_000); runCurrent()
        assertTrue("Ayu:jalan utama tertutup" in c.inbox, "C harus menerima lewat relay B: ${c.inbox}")
        assertTrue("Ayu:jalan utama tertutup" in b.inbox)
        assertTrue(a.inbox.isEmpty(), "pesan sendiri tidak kembali sebagai pesan masuk")
        assertEquals(setOf("0b0b0b0b0b0b0b0b"), a.engine.snapshot.value.peers.filter { it.direct }.map { it.peerId }.toSet())
    }

    @Test
    fun deliveryAckReturnsToOriginalSenderThroughRelay() = runTest {
        val radio = world()
        val a = phone(radio, "A", "0a0a0a0a0a0a0a0a", "Ayu")
        val b = phone(radio, "B", "0b0b0b0b0b0b0b0b", "Budi")
        val c = phone(radio, "C", "0c0c0c0c0c0c0c0c", "Citra")
        radio.setRssi("A", "B", -60); radio.setRssi("B", "C", -60)   // A tidak menjangkau C
        advanceTimeBy(MeshEngine.GOSSIP_PERIOD_MS + 6_000); runCurrent()
        val acks = mutableListOf<IncomingAck>()
        backgroundScope.launch { a.engine.acks.collect { acks += it } }
        val bAcks = mutableListOf<IncomingAck>()
        backgroundScope.launch { b.engine.acks.collect { bAcks += it } }

        val important = msg("Ayu", "[PENTING] semua tim kembali ke posko")
        a.engine.sendPublic(important)
        advanceTimeBy(2_000); runCurrent()
        c.engine.sendAck("0a0a0a0a0a0a0a0a", important.id)
        advanceTimeBy(2_000); runCurrent()

        assertEquals(listOf(IncomingAck(important.id, "0c0c0c0c0c0c0c0c")), acks, "konfirmasi C harus sampai ke A lewat B")
        assertTrue(bAcks.isEmpty(), "perantara hanya meneruskan, tidak menganggap konfirmasi untuk dirinya")
        assertTrue(c.inbox.none { it.contains(important.id) })
    }

    @Test
    fun deliveryAckCrossesLoraBackbone() = runTest {
        val radio = world()
        val n1 = node(radio, "N1", 1)
        val n2 = node(radio, "N2", 2)
        n1.loraPeers += n2; n2.loraPeers += n1
        val a = phone(radio, "A", "0a0a0a0a0a0a0a0a", "Ayu")
        val z = phone(radio, "Z", "0f0f0f0f0f0f0f0f", "Zaki")
        radio.setRssi("A", "N1", -60); radio.setRssi("Z", "N2", -60)
        advanceTimeBy(8_000); runCurrent()
        val acks = mutableListOf<IncomingAck>()
        backgroundScope.launch { a.engine.acks.collect { acks += it } }
        val sos = msg("Ayu", "SOS")
        a.engine.sendPublic(sos)
        advanceTimeBy(30_000); runCurrent()
        assertTrue("Ayu:SOS" in z.inbox)
        z.engine.sendAck("0a0a0a0a0a0a0a0a", sos.id)
        advanceTimeBy(30_000); runCurrent()
        assertEquals(listOf(sos.id), acks.map { it.messageId }, "konfirmasi harus kembali lewat LoRa")
    }

    @Test
    fun loraRxMeasurementIsPairedWithTheMessageItDescribes() = runTest {
        val radio = world()
        val n1 = node(radio, "N1", 1)
        val n2 = node(radio, "N2", 2)
        n1.loraPeers += n2; n2.loraPeers += n1
        n2.rxMeta = Triple(-97.5f, 6.25f, 9)       // firmware uji QoS di node penerima
        val a = phone(radio, "A", "0a0a0a0a0a0a0a0a", "Ayu")
        val z = phone(radio, "Z", "0f0f0f0f0f0f0f0f", "Zaki")
        radio.setRssi("A", "N1", -60); radio.setRssi("Z", "N2", -60)
        advanceTimeBy(8_000); runCurrent()
        n2.sendHealth(sf = 9, testMode = true); runCurrent()
        assertEquals(9, z.engine.snapshot.value.servingNode?.spreadingFactor)
        assertTrue(z.engine.snapshot.value.servingNode?.testMode == true)

        val received = mutableListOf<IncomingMessage>()
        backgroundScope.launch { z.engine.messages.collect { received += it } }
        a.engine.sendPublic(msg("Ayu", "@meshta-qos-v1|r1|1|10|9|||500m"))
        advanceTimeBy(30_000); runCurrent()
        val rx = assertNotNull(received.single { it.message.content.contains("qos") }.loraRx, "data ukur harus menempel di pesan")
        assertEquals(-97.5f, rx.rssiDbm)
        assertEquals(6.3f, rx.snrDb, "SNR dibulatkan 0,1 dB seperti firmware")
        assertEquals(9, rx.spreadingFactor)
        assertTrue(rx.matched, "msgId dari node harus cocok dengan paket yang diterima")
    }

    @Test
    fun electsStrongestNodeOnlyAndRegisters() = runTest {
        val radio = world()
        val n1 = node(radio, "N1", 1)
        val n2 = node(radio, "N2", 2)
        val a = phone(radio, "A", "0a0a0a0a0a0a0a0a", "Ayu")
        radio.setRssi("A", "N1", -82); radio.setRssi("A", "N2", -61)
        advanceTimeBy(8_000); runCurrent()
        assertTrue(radio.isConnected("A", "N2"))
        assertTrue(!radio.isConnected("A", "N1"), "hanya satu node boleh aktif")
        assertEquals(listOf("0a0a0a0a0a0a0a0a" to 0), n2.registrations.take(1))
        val serving = assertNotNull(a.engine.snapshot.value.servingNode)
        assertEquals(n2.peerId, serving.peerId)
        assertTrue(serving.registered)
        n2.sendHealth(neighbors = 1); runCurrent()
        assertEquals(1, a.engine.snapshot.value.servingNode?.loraNeighbors)
        assertEquals(1 to 3, a.engine.snapshot.value.servingNode?.userSlots)
        assertTrue(a.engine.snapshot.value.loraPathAvailable)
    }

    @Test
    fun nebengRouteThroughPhoneConnectedToNode() = runTest {
        val radio = world()
        val n1 = node(radio, "N1", 1)
        val a = phone(radio, "A", "0a0a0a0a0a0a0a0a", "Ayu")
        phone(radio, "B", "0b0b0b0b0b0b0b0b", "Budi")
        radio.setRssi("A", "B", -55); radio.setRssi("B", "N1", -60)   // A di luar jangkauan node
        advanceTimeBy(MeshEngine.GOSSIP_PERIOD_MS + 6_000); runCurrent()
        val nebeng = assertNotNull(a.engine.snapshot.value.nebeng, "A harus tahu bisa nebeng lewat B")
        assertEquals("0b0b0b0b0b0b0b0b", nebeng.relayPeerId)
        assertEquals("Budi", nebeng.relayName)
        assertEquals(n1.peerId, nebeng.nodeId)
        assertTrue(a.engine.snapshot.value.loraPathAvailable)
    }

    @Test
    fun messageCrossesLoraBackboneToAnotherVillage() = runTest {
        val radio = world()
        val n1 = node(radio, "N1", 1)
        val n2 = node(radio, "N2", 2)
        n1.loraPeers += n2; n2.loraPeers += n1
        val a = phone(radio, "A", "0a0a0a0a0a0a0a0a", "Ayu")
        val z = phone(radio, "Z", "0f0f0f0f0f0f0f0f", "Zaki")
        radio.setRssi("A", "N1", -60); radio.setRssi("Z", "N2", -60)
        advanceTimeBy(8_000); runCurrent()
        a.engine.sendPublic(msg("Ayu", "butuh air bersih di RT 3"))
        // Antrean node berjeda airtime (≥ 4 s per paket): beri waktu.
        advanceTimeBy(30_000); runCurrent()
        assertTrue("Ayu:butuh air bersih di RT 3" in z.inbox, "pesan harus melintas LoRa ke desa lain: ${z.inbox}")
    }

    @Test
    fun handoverToStrongerNodeWithRegistrationAndPrevNode() = runTest {
        val radio = world()
        val n1 = node(radio, "N1", 1)
        val n2 = node(radio, "N2", 2)
        val a = phone(radio, "A", "0a0a0a0a0a0a0a0a", "Ayu")
        a.engine.mobilityConfig = a.engine.mobilityConfig.copy(filterAlpha = 1f)
        radio.setRssi("A", "N1", -58); radio.setRssi("A", "N2", -88)
        advanceTimeBy(8_000); runCurrent()
        assertEquals(n1.peerId, a.engine.snapshot.value.servingNode?.peerId)

        // Ayu berjalan ke arah N2.
        radio.setRssi("A", "N1", -86); radio.setRssi("A", "N2", -60)
        advanceTimeBy(30_000); runCurrent()
        assertEquals(n2.peerId, a.engine.snapshot.value.servingNode?.peerId, "log: ${a.log}")
        assertTrue(radio.isConnected("A", "N2") && !radio.isConnected("A", "N1"))
        assertEquals("0a0a0a0a0a0a0a0a" to 1, n2.registrations.last(), "registrasi membawa node sebelumnya")
        assertTrue(a.log.any { it.startsWith("ATTEMPT") } && a.log.any { it.startsWith("SUCCESS") }, a.log.toString())
    }

    @Test
    fun oversizeOnlyUsesBleAndLoraStillCarriesFiles() = runTest {
        val radio = world()
        val n1 = node(radio, "N1", 1)
        val n2 = node(radio, "N2", 2)
        n1.loraPeers += n2; n2.loraPeers += n1
        val a = phone(radio, "A", "0a0a0a0a0a0a0a0a", "Ayu")
        val b = phone(radio, "B", "0b0b0b0b0b0b0b0b", "Budi")
        val z = phone(radio, "Z", "0f0f0f0f0f0f0f0f", "Zaki")
        radio.setRssi("A", "B", -55); radio.setRssi("A", "N1", -60); radio.setRssi("Z", "N2", -60)
        advanceTimeBy(8_000); runCurrent()

        val big = FilePacket("terlalu-besar.bin", "application/octet-stream", ByteArray(97 * 1024) { (it * 31).toByte() })
        a.engine.sendFile(big)
        advanceTimeBy(3 * 60_000); runCurrent()
        assertEquals(1, b.files.size, "HP tetangga menerima berkas besar lewat fragmen BLE")
        assertTrue(b.files[0].content.contentEquals(big.content))
        assertTrue(z.files.isEmpty(), "payload di atas 96 KB tidak masuk antrean LoRa")

        val small = FilePacket("lora.webp", "image/webp", ByteArray(900) { it.toByte() })
        a.engine.sendFile(small)
        advanceTimeBy(60_000); runCurrent()
        assertEquals(listOf("lora.webp"), z.files.map { it.fileName }, "berkas kecil melintas LoRa")
    }
}

@Suppress("unused")
private fun CoroutineScope.unusedMarker() = Unit
