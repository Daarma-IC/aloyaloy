NusaMesh iOS SOURCE PACKAGE - this is NOT an IPA.
Extract on a Mac and follow docs/RELEASE.md.
Native Codec2 source is included; no private signing credentials are included.
iOS compilation, signing and device verification have not run on the Windows packaging host.
